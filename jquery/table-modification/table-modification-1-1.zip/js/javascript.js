function styleTable(){
    $(function() {
        $("#tableStyledInJavascript tr:even").not('thead tr').addClass("stripe1");
        $("#tableStyledInJavascript tr:odd").not('thead tr').addClass("stripe2");

        $("#tableStyledInJavascript tr").not('thead tr').hover(
            function() {
            $(this).toggleClass("highlight");
            },
            function() {
            $(this).toggleClass("highlight").css( 'cursor', 'pointer' );
            });
            
            $("#tableStyledInJavascript").on("click", "td.choosenColor", function showText (evt) {
                $("#colorPanel").animate({width:'toggle'},350);
                var choosenColor= $(this).text();
                $("#colorPanel").html(choosenColor).css("background-color", choosenColor);
                setTimeout(function() {
                    $("#colorPanel").animate({width:'toggle'},200);
                    }, 3000);
            });

            countRows();

            /* add delete button  .ui-icon-circle-minus*/
            var objCurrentRow = $('#tableStyledInJavascript tr').not('thead tr');
            objCurrentRow.append('<div class="deleteRow" style="width: 80px"><a href="">Delete</a></div>')
    });
}

function addRow() {
    $("#btnAdd").on("click", function showText (evt) {
        $("#addRowPanel").toggle();

        $("#addRowPanel").on("click", "#btnAddRow", function submitRow() {
            var inpColor = $("#inpColor").val(); 
            var inpCost = $("#inpCost").val();
            var inpAvailability = $("#inpAvailability option:selected").text(); 
            
            console.info('The input color is: ' + inpColor + 'with the cost of' + inpCost + 'and the availability of ' + inpAvailability + '.');
            countRows();
            
            $("#tableStyledInJavascript tr").last().after('<tr><td>' +inpColor + '</td><td>' + inpCost + '</td><td>' + inpAvailability + '</td></tr>');
            $("#tableStyledInJavascript tr").last().append('<div class="deleteRow"><td><a href="">Delete</a></td></div>');
            $("#tableStyledInJavascript tr:even").addClass("stripe1");
            $("#tableStyledInJavascript tr:odd").addClass("stripe2");
            $("#addRowPanel").toggle();
            
       
            /* Clear the input boxes */
            inpColor ="";
            inpCost ="";
            inpAvailability="";
            });

    });
    countRows();
}

function deleteRows(){
        $("#tableStyledInJavascript tbody tr").on('click', function(event) {
            $(this).remove();
            $("#tableStyledInJavascript tr:even").not('thead tr').addClass("stripe1");
            $("#tableStyledInJavascript tr:odd").not('thead tr').addClass("stripe2");
            
            countRows();
            //update array with information from the table
            

            //Export the array to the console formatted for viewing

            return false;
        });
}

function countRows() {
    var rowCount = $('#tableStyledInJavascript tr').not('thead tr').length;
    console.info('There are ' + rowCount + ' rows in the table.');

}

function onFunctions(){
    deleteRows();
}


$(document).ready(function () {
        styleTable();
        addRow();
        onFunctions();
        $('#picturesPanel').find('a').colorbox({width: '450', height: '300'});
 });