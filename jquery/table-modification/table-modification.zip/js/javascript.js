function styleTable(){
    $(function() {
        $("#tableStyledInJavascript tr:even").addClass("stripe1");
        $("#tableStyledInJavascript tr:odd").addClass("stripe2");

        $("#tableStyledInJavascript tr").hover(
            function() {
            $(this).toggleClass("highlight");
            },
            function() {
            $(this).toggleClass("highlight");
            }).css( 'cursor', 'pointer' );

            $("#tableStyledInJavascript").on("click", "td.choosenColor", function showText (evt) {
                $("#colorPanel").animate({width:'toggle'},350);
                var choosenColor= $(this).text();
                $("#colorPanel").html(choosenColor).css("background-color", choosenColor);
                setTimeout(function() {
                    $("#colorPanel").animate({width:'toggle'},200);
                    }, 3000);
            });
    });
}

function addRow() {
    $("#btnAdd").on("click", function showText (evt) {
        $("#addRowPanel").toggle();

        $("#addRowPanel").on("click", "#btnAddRow", function submitRow() {
            var inpColor = $("#inpColor").val();
            console.info(inpColor); 
            var inpCost = $("#inpCost").val();
            console.info(inpCost);
            var inpAvailability = $("#inpAvailability option:selected").text(); 
            console.info(inpAvailability);

            $("#tableStyledInJavascript tr").last().after('<tr><td>' +inpColor + '</td><td>' + inpCost + '</td><td>' + inpAvailability + '</td></tr>');
            $("#tableStyledInJavascript tr:even").addClass("stripe1");
            $("#tableStyledInJavascript tr:odd").addClass("stripe2");
            $("#addRowPanel").toggle();
            
            /* Clear the input boxes */
            $("#inpCost").val() = "";
            inpCost ="";
            inpAvailability="";
            });
    });
}

function delRow() {
    var par = $(this).parent().parent(); //tr 
    par.remove(); 
}; 

$(document).ready(function () {
        styleTable();
        addRow();
 });